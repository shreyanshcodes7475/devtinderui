const Feed=()=>{
    return(
        <div>
            <h1>FEED</h1>
        </div>
    )
}

export default Feed;