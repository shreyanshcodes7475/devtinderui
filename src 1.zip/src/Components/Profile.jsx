const Profile=()=>{
    return(
        <>
        <h1>Profile</h1>
        </>
    )
}

export default Profile;